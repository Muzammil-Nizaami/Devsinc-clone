const myDiv = document.getElementById('stcall');
myDiv.addEventListener('mouseover', function() {
    console.log("hovered");
  myDiv.style.backgroundColor = '#042638'; 
});
myDiv.addEventListener('mouseout', function() {
  myDiv.style.backgroundColor = '#0ebab1'; 
});

const myDiv2 = document.getElementById('banners01');
myDiv2.addEventListener('mouseover', function() {
    console.log("hovered");
  myDiv2.style.backgroundColor = '#042638';
});
myDiv2.addEventListener('mouseout', function() {
  myDiv2.style.backgroundColor = '#0ebab1'; 
});


const myDiv3 = document.getElementById('banners02');
myDiv3.addEventListener('mouseover', function() {
    console.log("hovered");
  myDiv3.style.backgroundColor = '#042638'; 
  myDiv3.style.color="white";

  
});
myDiv3.addEventListener('mouseout', function() {
  myDiv3.style.backgroundColor = '#e9e9e9'; 
  myDiv3.style.color="#042638";
});




const myDiv4 = document.querySelector(".otherservices");

myDiv4.addEventListener('mouseover', function() {
    console.log("hovered");
    myDiv4.style.backgroundColor = '#fafafa'; 
   
});
myDiv4.addEventListener('mouseout', function() {
  myDiv4.style.backgroundColor = 'white';
});


const elementStyleLink = myDiv4.querySelector('.elementStyle');
console.log(elementStyleLink);



elementStyleLink.addEventListener('mouseover',function(){
console.log("hoveres in web")

    elementStyleLink.style.color="#0ebab1";
});

elementStyleLink.addEventListener('mouseout',function(){

        elementStyleLink.style.color="rgb(24, 0, 48)";
})



